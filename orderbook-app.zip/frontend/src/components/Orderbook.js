
import React, { useState, useEffect } from 'react';

function Orderbook() {
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState(null);

  useEffect(() => {
    if (quantity) {
      fetch(`http://localhost:8000/price?quantity=${quantity}`)
        .then(response => response.json())
        .then(data => setPrice(data.price))
        .catch(error => console.error('Error fetching price:', error));
    }
  }, [quantity]);

  return (
    <div>
      <input
        type="number"
        value={quantity}
        onChange={e => setQuantity(e.target.value)}
        placeholder="Enter USDT quantity"
      />
      {price !== null && (
        <div>
          <p>Price in ZAR: {price}</p>
        </div>
      )}
    </div>
  );
}

export default Orderbook;
