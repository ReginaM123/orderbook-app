
import React from 'react';
import Orderbook from './components/Orderbook';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Orderbook App</h1>
      </header>
      <Orderbook />
    </div>
  );
}

export default App;
