
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from orderbook import OrderBook

app = FastAPI()
orderbook = OrderBook()

class OrderRequest(BaseModel):
    quantity: float

@app.get("/price")
async def get_price(quantity: float):
    try:
        price = orderbook.get_price(quantity)
        return {"price": price}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
