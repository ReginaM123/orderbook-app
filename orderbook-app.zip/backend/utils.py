
def parse_orderbook_update(message):
    # Placeholder function to parse orderbook updates
    bids = []
    asks = []
    return bids, asks
